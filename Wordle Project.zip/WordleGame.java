import java.util.Scanner;

public class WordleGame 
{
    private int guesses; //field variable for the amount of guesses 
    private Word word; //field variable for the word of the day 
    private Word wordguess = new Word(""); //field variable for the user's input/guess
    private Word alphabet = new Word("ABCDEFGHIJKLMNOPQRSTUVWXYZ"); //field variable for  the available letters
    private Word currentCombination; //field variable for the user's current solution
    
    /**
    *default no-args constructor sets the inital parameters of the game
    */
    public WordleGame()
    {
        word=new Word("blank");
        guesses=6;
        currentCombination = new Word(word.starPlacer(word.getLength()));   
    }

    /**
    *overloaded constructor takes two parameters, one for the word of the day and the second for the amount of gueses
    */
    public WordleGame(Word s,int designerInputGuesses)
    {
        word = s;
        guesses=designerInputGuesses;
        currentCombination = new Word(word.starPlacer(word.getLength()));   
    }   
    
    /**
    *startPrompts handles the user interaction of prompting the user and getting guesses
    *multiple embedded helper methods that will be explained throughout
    */
    public void startPrompts()
    {
        System.out.println("Welcome to WORDLE! Here's how to play: Guess the WORDLE in " + guesses + " tries. Hit the enter button to submit. After each guess, the orientation of the alphabet shown will change to show how close your guess was to the word." + "\n");

        while(!(wordguess.getWord().equals(word.getWord())) || (guesses<=0)) //while loop condition will repeat as long as the user's input does not equal the word of if the guesses are greater than 0
        {
            askAndRecieve(); //takes user inputs
            if(guesses==0 && !(wordguess.getWord().equals(word.getWord()))) //informs the user that they have lost if the guesses are 0 and their guess does not equal the word
            {
                System.out.println("Sorry, you have run out of available guesses");
                System.out.println("The solution to today's WORDLE was " + word.getWord());
                break;
            }
            if(wordguess.getWord().equals(word.getWord()))//informs the user that they have won if their guess matches the word of the day
            {
                System.out.println("Great Job! You have solved today's WordleGame " + word.getWord() + " with " + guesses + " guesses left!");
                break;
            }
        }
    }
    /**
    *boolean method checks to see if the length of the user's guess equals the length of the word
    */
    public boolean sameNumOfLetters(int first, int last) 
    {
        if(first==last)
        {            
            return true;
        }
        else
        {
            System.out.println("Word Length Not Valid/Accepted." + "\n"); //informs user that the length is not the same
            return false;
        }
    }
    
    /*public boolean samePosition(String guess, int x)
    {
        return (word.getWord().charAt(x) == guess.charAt(x));
    }
    public boolean containsLetter (String guess, int x)
    {
        return (word.getWord().contains(guess.substring(x,x+1)));
    }
    */
    
    /**
    *askAndReceive method for obtaining information fromt the user
    *also informs the user the status of their game (guesses, information about letters, an their current solution)
    */
    public void askAndRecieve()
    {
        System.out.println("You have " + guesses + " guess(es) left.");
        System.out.println("Available Letters: " + alphabet.getWord());
        System.out.println("Current Combination: " + currentCombination.getWord() + "\n");
        
        Scanner c = new Scanner(System.in);
        //do while loop prompts the user a word until it is the same length and only contains characters from the alphabet
        do
        {
            System.out.print("Please enter a valid "+ word.getLength() +" letter word: ");
            wordguess.setWord(c.nextLine());
        }
        while(!(wordguess.onlyContainsChar() && (sameNumOfLetters(word.getLength(),wordguess.getLength())))); 
        
        //for loop checks through every character in word
        for(int i=0; i<wordguess.getLength();i++)
        { 
                String comparer = "";
                comparer=wordguess.getWord().substring(i,i+1); 
                
                if(word.getWord().contains(wordguess.getWord().substring(i,i+1))) //if statement checks through every character of both words
                { 
                    if(word.getWord().substring(i,i+1).equals(wordguess.getWord().substring(i,i+1))) //if the letter is a perfect match in terms of containment and positioning
                    { 
                        currentCombination.addToStars(wordguess.getWord(),i); 
                    }                        
                    alphabet.appropriateLowercase(wordguess.getWord().substring(i,i+1));
                }
                else if(!(word.getWord().contains(wordguess.getWord().substring(i,i+1)))) //if the letter is contained in the word but not in the correct position
                {
                    alphabet.replacer(comparer,"_");
                }
                
        }
        guesses--; //decrements the amount of guesses that are left
    }

}
