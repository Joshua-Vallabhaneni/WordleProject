public class Portal 
{
    public static void main(String[] args) 
    {
        //WordleGame game = new WordleGame(); //WordleGame no args makes default 6 guesses for a 5 letter word
        WordleGame game = new WordleGame(new Word("stare"),6);
        game.startPrompts();
    }

}
