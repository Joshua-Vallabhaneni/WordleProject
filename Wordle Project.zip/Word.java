public class Word
{
    private String word; //field variable word holds value as a String object
    
    /**
    *1st Word constructor that takes a string parameter and sets it equal to the word field variable 
    *Constructor also makes the word object uppercase
    */
    public Word(String s)
    {
        word = new String(s);
        word=word.toUpperCase();
    }
    
    /**
    *Default no-args constructor that takes sets the word object and sets it to "blank"
    *Constructor also makes the word object uppercase
    */
    public Word()
    {
        word=new String("blank");
        word=word.toUpperCase();
    }
    /**
    *Accessor/Gettor Method that returns word
    */
    public String getWord()
    {
        return word;
    }
    /**
    *Accessor/Gettor Method that returns the length of the word
    */
    public int getLength()
    {
        return word.length();
    }
    /**
    *Mutator/Modifier Method that takes a string parameter and allows it to be set to the word
    */
    public void setWord(String s)
    {
        word=s;
    }
    /**
    *Boolean method checks if the word has any other characters apart from the alphabet
    */
    public boolean onlyContainsChar()
    {
        word=word.toUpperCase();
        return word.matches("[a-zA-Z]+"); //[a-zA-Z]+ idea explored online -- a-z checks for lowercase alphabet, A-Z checks for uppercase alphabet
        //.matches checks whether or not this string matches given expression
    }

    /**
    *String method takes two String parameters and replaces a specific portion of a String with another portion
    */
    public String replacer(String a, String b)
    {
        word=word.replaceAll(a,b); //replaceAll() returns a string replacing all the sequence of characters for the given inputs
        return word;
    }
    
    /**
    *replaces the first substring of the string g, using the replaceFirst method, to lowercase and stores it as word 
    */
    public void appropriateLowercase(String g)
    {
        word=word.replaceFirst(g,g.toLowerCase());
    }
    /**
    *String method takes an integer value and replaces it with astreisks using a for loop
    */
    public String starPlacer(int a)
    {
        String word = "";
        for(int i=0; i<a; i++)
        {
            word += "*";
        }
        return word;
    }
    /**
    *addToStars method takes two parameters and based on whether the user guesses the right letter will modify it to an asterisk 
    */
    public void addToStars(String userInput, int position)
    {
        word= word.substring(0, position) + (userInput.substring(position,position+1)) + (word.substring(position+1));
    }
    

}